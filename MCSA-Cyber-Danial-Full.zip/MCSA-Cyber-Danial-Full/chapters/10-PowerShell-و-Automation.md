# فصل 10 — PowerShell و Automation

Cmdlet، Pipeline، Object، Variable، Filter، Export و Automation.

## نکات کلیدی
- PowerShell با Objectها کار می‌کند.
- Pipeline خروجی یک دستور را به ورودی دستور بعدی می‌دهد.
- Get-Command برای پیدا کردن Cmdlet و Get-Help برای یادگیری آن‌هاست.
- اسکریپت‌ها باید با حداقل دسترسی لازم اجرا شوند.

## دستورها
```powershell
Get-Command *-Service
```
```powershell
Get-Help Get-Service -Examples
```
```powershell
Get-Service | Where-Object {$_.Status -eq 'Running'}
```
```powershell
Get-Process | Sort-Object CPU -Descending
```
```powershell
Get-Service | Export-Csv C:\Temp\services.csv -NoTypeInformation
```