# فصل 08 — IIS و Web Server

IIS، Site، Binding، Application Pool، HTTP/HTTPS و مدیریت وب.

## نکات کلیدی
- IIS وب‌سرور مایکروسافت برای Windows Server است.
- Site می‌تواند Bindingهای HTTP و HTTPS داشته باشد.
- Application Pool محیط اجرای Application را مدیریت می‌کند.
- HTTPS به Certificate نیاز دارد.
- لاگ‌ها برای عیب‌یابی IIS مهم‌اند.

## دستورها
```powershell
Get-WindowsFeature Web-Server
```
```powershell
Get-Website
```
```powershell
Get-WebAppPoolState -Name DefaultAppPool
```
```powershell
Restart-WebAppPool DefaultAppPool
```
```powershell
iisreset
```