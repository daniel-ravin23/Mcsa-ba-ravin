# فصل 04 — DNS Server

Zone، Record، Forwarder، Reverse Lookup و نقش DNS در Active Directory.

## نکات کلیدی
- A Record نام را به IPv4 نگاشت می‌کند.
- AAAA برای IPv6 است.
- CNAME نام مستعار ایجاد می‌کند.
- PTR برای Reverse Lookup استفاده می‌شود.
- DNS صحیح برای پیدا کردن سرویس‌های AD ضروری است.

## دستورها
```powershell
nslookup dc01.example.local
```
```powershell
Resolve-DnsName example.com
```
```powershell
Get-DnsServerZone
```
```powershell
Get-DnsServerResourceRecord -ZoneName example.local
```
```powershell
ipconfig /flushdns
```
```powershell
ipconfig /registerdns
```