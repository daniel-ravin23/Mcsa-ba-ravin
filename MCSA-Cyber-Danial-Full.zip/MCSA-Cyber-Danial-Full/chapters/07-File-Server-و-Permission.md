# فصل 07 — File Server و Permission

Share، NTFS، Share Permission، Inheritance، Ownership و دسترسی امن.

## نکات کلیدی
- NTFS Permission روی فایل‌سیستم اعمال می‌شود.
- Share Permission هنگام دسترسی شبکه مطرح است.
- Least Privilege یعنی حداقل دسترسی لازم را بدهیم.
- گروه‌ها برای مدیریت دسترسی بهتر از کاربر به‌کاربر هستند.
- Inheritance باعث انتقال Permission از والد به فرزند می‌شود.

## دستورها
```powershell
Get-SmbShare
```
```powershell
New-SmbShare -Name Data -Path C:\Data
```
```powershell
Get-SmbShareAccess -Name Data
```
```powershell
icacls C:\Data
```
```powershell
Get-Acl C:\Data
```