# فصل 03 — Active Directory Domain Services

ساخت Domain، Domain Controller، کاربران، گروه‌ها، OUها و Computer Account.

## نکات کلیدی
- AD DS پایگاه مرکزی هویت و منابع Domain است.
- OU برای سازمان‌دهی اشیای AD و مدیریت متمرکز استفاده می‌شود.
- گروه‌ها مدیریت Permission را ساده می‌کنند.
- Domain Controller احراز هویت و سرویس‌های Domain را ارائه می‌کند.

## دستورها
```powershell
Get-ADDomain
```
```powershell
Get-ADUser -Filter *
```
```powershell
Get-ADComputer -Filter *
```
```powershell
Get-ADGroup -Filter *
```
```powershell
New-ADUser -Name 'Ali' -SamAccountName 'ali'
```
```powershell
Get-ADOrganizationalUnit -Filter *
```