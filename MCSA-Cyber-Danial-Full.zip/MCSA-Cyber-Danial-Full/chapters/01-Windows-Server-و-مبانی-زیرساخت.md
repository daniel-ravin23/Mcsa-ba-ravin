# فصل 01 — Windows Server و مبانی زیرساخت

شناخت Windows Server، IP، Subnet، Gateway، DNS، DHCP، Domain و ابزارهای مدیریتی.

## نکات کلیدی
- Windows Server برای ارائه و مدیریت سرویس‌های شبکه استفاده می‌شود.
- Server سرویس ارائه می‌کند و Client از سرویس استفاده می‌کند.
- DNS نام را به IP نگاشت می‌کند و DHCP تنظیمات شبکه را خودکار می‌دهد.
- Domain محیط مدیریت متمرکز کاربران و کامپیوترهاست.
- Domain Controller سروری است که AD DS روی آن نصب شده است.

## دستورها
```powershell
hostname
```
```powershell
ipconfig /all
```
```powershell
ping 192.168.10.1
```
```powershell
nslookup example.com
```
```powershell
Get-NetIPAddress
```
```powershell
Get-NetAdapter
```
```powershell
Get-Service
```