# فصل 12 — Troubleshooting و سناریوی نهایی

روش عیب‌یابی مرحله‌ای و سناریوی ساخت Lab کامل.

## نکات کلیدی
- مشکل را دقیق تعریف و تغییرات اخیر را بررسی کنید.
- Layerها را از Connectivity تا DNS و Application بررسی کنید.
- برای Domain ابتدا Connectivity، DNS، Time و سپس Authentication را بررسی کنید.
- Event Viewer و PowerShell منابع مهم تحلیل خطا هستند.
- هر تغییر را ثبت کنید تا امکان Rollback و مقایسه وجود داشته باشد.

## دستورها
```powershell
Test-NetConnection dc01 -Port 53
```
```powershell
Test-NetConnection dc01 -Port 88
```
```powershell
Test-NetConnection dc01 -Port 389
```
```powershell
dcdiag
```
```powershell
repadmin /replsummary
```
```powershell
Get-WinEvent -LogName System -MaxEvents 50
```