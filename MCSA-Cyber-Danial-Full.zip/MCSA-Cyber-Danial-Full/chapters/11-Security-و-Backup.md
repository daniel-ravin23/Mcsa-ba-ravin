# فصل 11 — Security و Backup

Least Privilege، Firewall، Updates، Auditing، Backup و Hardening.

## نکات کلیدی
- امنیت Server فقط با Antivirus تأمین نمی‌شود.
- سرویس‌ها و Portهای غیرضروری باید محدود شوند.
- Backup باید قابل بازیابی و مستقل از سیستم اصلی باشد.
- Auditing برای بررسی رخدادهای امنیتی مهم است.
- قبل از تغییرات حساس برنامه Rollback داشته باشید.

## دستورها
```powershell
Get-NetFirewallProfile
```
```powershell
Get-NetFirewallRule
```
```powershell
Get-WinEvent -LogName Security -MaxEvents 20
```
```powershell
wbadmin get versions
```
```powershell
Get-MpComputerStatus
```