# فصل 05 — DHCP Server

Scope، Exclusion، Reservation، Lease و Optionها.

## نکات کلیدی
- Scope محدوده IP قابل واگذاری است.
- Exclusion بخشی است که DHCP واگذار نمی‌کند.
- Reservation یک IP مشخص را به Client مشخص وابسته می‌کند.
- Lease مدت اعتبار تخصیص IP است.
- Gateway و DNS می‌توانند از DHCP ارائه شوند.

## دستورها
```powershell
Get-DhcpServerv4Scope
```
```powershell
Get-DhcpServerv4Lease
```
```powershell
Get-DhcpServerv4Reservation
```
```powershell
Get-DhcpServerv4OptionValue
```
```powershell
ipconfig /release
```
```powershell
ipconfig /renew
```