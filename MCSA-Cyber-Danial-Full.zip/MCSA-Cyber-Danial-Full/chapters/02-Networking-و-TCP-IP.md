# فصل 02 — Networking و TCP/IP

IPv4/IPv6، Subnetting، TCP/UDP، Port، ARP، Routing و عیب‌یابی.

## نکات کلیدی
- IPv4 از چهار Octet تشکیل می‌شود؛ نمونه 192.168.10.20.
- شبکه /24 معمولاً Mask برابر 255.255.255.0 دارد.
- TCP اتصال‌گرا و UDP بدون اتصال پایدار است.
- Portها سرویس‌ها را از هم تفکیک می‌کنند.
- Gateway مسیر خروج از شبکه محلی است.

## دستورها
```powershell
ipconfig /all
```
```powershell
ping 192.168.10.1
```
```powershell
tracert 8.8.8.8
```
```powershell
arp -a
```
```powershell
route print
```
```powershell
Test-NetConnection 192.168.10.10 -Port 445
```