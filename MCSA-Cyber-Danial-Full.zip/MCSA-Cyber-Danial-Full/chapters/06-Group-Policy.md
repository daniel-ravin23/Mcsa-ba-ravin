# فصل 06 — Group Policy

GPO، Scope، Link، Security Filtering و تنظیمات User/Computer.

## نکات کلیدی
- GPO مجموعه‌ای از تنظیمات مدیریتی است.
- ترتیب پردازش Policyها اهمیت دارد.
- OUها محل مناسبی برای لینک GPO هستند.
- Computer Configuration روی کامپیوتر و User Configuration روی کاربر اعمال می‌شود.
- برای عیب‌یابی GPO از Resultant Set of Policy استفاده می‌شود.

## دستورها
```powershell
gpupdate /force
```
```powershell
gpresult /r
```
```powershell
gpresult /h C:\Temp\gpo.html
```
```powershell
Get-GPO -All
```
```powershell
Get-GPLink -Name 'OU=Users,DC=example,DC=local'
```