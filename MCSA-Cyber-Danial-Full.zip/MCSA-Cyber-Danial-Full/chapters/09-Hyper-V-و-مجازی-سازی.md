# فصل 09 — Hyper-V و مجازی‌سازی

VM، Virtual Switch، Checkpoint و مدیریت ماشین‌های مجازی.

## نکات کلیدی
- Hyper-V برای اجرای ماشین‌های مجازی است.
- External Switch برای اتصال VM به شبکه فیزیکی استفاده می‌شود.
- Internal و Private Switch کاربردهای متفاوت دارند.
- Checkpoint جایگزین Backup نیست.

## دستورها
```powershell
Get-VM
```
```powershell
Get-VMSwitch
```
```powershell
Start-VM -Name LAB-DC01
```
```powershell
Stop-VM -Name LAB-DC01
```
```powershell
Get-VMNetworkAdapter -VMName LAB-DC01
```